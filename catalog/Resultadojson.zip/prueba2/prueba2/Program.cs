﻿using System;
using System.Text;
namespace prueba2json
{
    class Program
    {
        static void Main(string[] args)
        {
            string ubicacionArchivo1 = "C:\\Users\\andre\\Downloads\\PruebasCandidatos\\PruebasCandidatos\\Catalog\\Categories.csv";
            string ubicacionArchivo2 = "C:\\Users\\andre\\Downloads\\PruebasCandidatos\\PruebasCandidatos\\Catalog\\Products.csv";

            System.IO.StreamReader archivo1 = new System.IO.StreamReader(ubicacionArchivo1, Encoding.UTF8);
            System.IO.StreamReader archivo2 = new System.IO.StreamReader(ubicacionArchivo2, Encoding.UTF8);

            string separador = ";";
            string json;
            string json2;


            List<Category> listaCategorias = new List<Category>();

            // lectura del archivo de categorias
            archivo1.ReadLine();
            while ((json = archivo1.ReadLine()) != null)
            {
                string[] fila = json.Split(separador);
                int Id = Convert.ToInt32(fila[0]);
                string Name = fila[1];
                string Description = fila[2];

                Category categoria = new Category()
                {
                    Id = Id,
                    Name = Name,
                    Description = Description
                };

                listaCategorias.Add(categoria);
            }

            // lectura del archivo de productos
            archivo2.ReadLine();
            while ((json2 = archivo2.ReadLine()) != null)
            {
                string[] fila = json2.Split(separador);
                int Id = Convert.ToInt32(fila[0]);
                int CategoryId = Convert.ToInt32(fila[1]);
                string Name = fila[2];
                double Price = Convert.ToDouble(fila[3], new System.Globalization.CultureInfo("es-ES"));

                // busqueda de la categoria correspondiente al producto
                Category categoria = listaCategorias.Find(c => c.Id == CategoryId);
                // si la categoria fue encontrada, agregamos el producto a la lista
                if (categoria != null)
                {
                    Product producto = new Product()
                    {
                        Id = Id,
                        CategoryId = CategoryId,
                        Name = Name,
                        Price = Price
                    };
                    categoria.Products.Add(producto);
                }
            }

            var resultado = "[\n";
            // ciclo para generar el json de salida
            foreach (Category categoria in listaCategorias)
            {
                resultado += "  {\n";
                resultado += "    \"Id\": " + categoria.Id + ",\n";
                resultado += "    \"Name\": \"" + categoria.Name + "\",\n";
                resultado += "    \"Description\": \"" + categoria.Description + "\",\n";
                resultado += "    \"Products\": [\n";

                // ciclo para agregar los productos de la categoria correspondiente
                foreach (Product producto in categoria.Products)
                {
                    resultado += "      {\n";
                    resultado += "        \"Id\": " + producto.Id + ",\n";
                    resultado += "        \"CategoryId\": " + producto.CategoryId + ",\n";
                    resultado += "        \"Name\": \"" + producto.Name + "\",\n";
                    resultado += "        \"Price\": " + producto.Price.ToString().Replace(",", "") + ".0\n";

                    //valida si es el ultimo producto a imprimir
                    if (categoria.Products.IndexOf(producto) == categoria.Products.Count - 1)
                    {
                        resultado += "      }\n";
                        resultado += "   ]\n";
                    }
                    else
                    {
                        resultado += "      },\n";
                    }
                }
                //valida si es la categoria final para imprimir el corchete final
                if (listaCategorias.IndexOf(categoria) == listaCategorias.Count - 1)
                {
                    resultado += "   }\n";
                }
                else
                {
                    resultado += "  },\n";
                }
            }
            resultado += "]\n";
            System.IO.File.WriteAllText(@"C:\Users\andre\Downloads\catalogo.json", resultado);
            Console.WriteLine("El archivo output.js fue generado con éxito.");
        }

    }


    // clase Category, contiene los atributos Id, Name, Description y una lista de productos
    class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        // se inicializa una lista de productos vacia, para poder agregar los productos posteriormente
        public List<Product> Products { get; set; } = new List<Product>();
    }

    // clase Product, contiene los atributos Id, CategoryId, Name y Price
    class Product
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }
}