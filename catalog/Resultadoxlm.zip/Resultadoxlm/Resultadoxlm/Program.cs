﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace prueba2_xml
{
    class Program
    {
        static void Main(string[] args)
        {
            string ubicacionArchivo1 = "C:\\Users\\andre\\Downloads\\PruebasCandidatos\\PruebasCandidatos\\Catalog\\Categories.csv";
            string ubicacionArchivo2 = "C:\\Users\\andre\\Downloads\\PruebasCandidatos\\PruebasCandidatos\\Catalog\\Products.csv";

            System.IO.StreamReader archivo1 = new System.IO.StreamReader(ubicacionArchivo1);
            System.IO.StreamReader archivo2 = new System.IO.StreamReader(ubicacionArchivo2);

            string separador = ";";
            string json;

            List<Category> listaCategorias = new List<Category>();

            // lectura del archivo de categorias
            archivo1.ReadLine();
            while ((json = archivo1.ReadLine()) != null)
            {
                string[] fila = json.Split(separador);
                int Id = Convert.ToInt32(fila[0]);
                string Name = fila[1];
                string Description = fila[2];

                Category categoria = new Category()
                {
                    Id = Id,
                    Name = Name,
                    Description = Description
                };

                listaCategorias.Add(categoria);
            }

            // lectura del archivo de productos
            archivo2.ReadLine();
            while ((json = archivo2.ReadLine()) != null)
            {
                string[] fila = json.Split(separador);
                int Id = Convert.ToInt32(fila[0]);
                int CategoryId = Convert.ToInt32(fila[1]);
                string Name = fila[2];
                double Price = Convert.ToDouble(fila[3], new System.Globalization.CultureInfo("es-ES"));

                // busqueda de la categoria correspondiente al producto
                Category categoria = listaCategorias.Find(c => c.Id == CategoryId);
                // si la categoria fue encontrada, agregamos el producto a la lista
                if (categoria != null)
                {
                    Product producto = new Product()
                    {
                        Id = Id,
                        CategoryId = CategoryId,
                        Name = Name,
                        Price = Price
                    };
                    categoria.Products.Add(producto);
                }
            }

            var resultado = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
             resultado += "<ArrayOfCategory xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://schemas.datacontract.org/2004/07/Catalog\">\n";
            // ciclo para generar el xml de salida
            resultado += "<category>\n";
            foreach (Category categoria in listaCategorias)

            {   resultado += "    <Description>" + categoria.Description + "</Description>\n";
                resultado += "    <Id>" + categoria.Id + "</Id>\n";
                resultado += "    <Name>" + categoria.Name + "</Name>\n";
                resultado += "    <Products>\n";

                // ciclo para agregar los productos de la categoria correspondiente
                foreach (Product producto in categoria.Products)
                {
                    resultado += "        <product>\n";
                    resultado += "        <Id>" + producto.Id + "</Id>\n";
                    resultado += "        <CategoryId>" + producto.CategoryId + "</CategoryId>\n";
                    resultado += "        <Name>" + producto.Name + "</Name>\n";
                    resultado += "        <Price>" + producto.Price.ToString().Replace(",", "") + "</Price>\n";

                    //valida si es el ultimo producto a imprimir
                    if (categoria.Products.IndexOf(producto) == categoria.Products.Count - 1)
                    {
                        resultado += "        </product>\n";
                        resultado += "     </Products>\n";
                    }
                    else
                    {
                        resultado += "      </product>\n";
                    }
                }
                //valida si es la categoria final para imprimir el cierre de categoria final
                if (listaCategorias.IndexOf(categoria) == listaCategorias.Count - 1)
                {
                    resultado += "   </category>\n";
                }
                else
                {
                    resultado += "  </category>\n";
                }
            }

            resultado += "</ArrayOfCategory>\n";

            // crea el archivo si no existe o si existe lo sobreescribe
            System.IO.File.WriteAllText(@"C:\Users\andre\Downloads\catalogo.xml", resultado);
            Console.WriteLine("El archivo output.xml fue generado con éxito.");
        }

    }


    // clase Category, contiene los atributos Id, Name, Description y una lista de productos
    class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        // se inicializa una lista de productos vacia, para poder agregar los productos posteriormente
        public List<Product> Products { get; set; } = new List<Product>();
    }

    // clase Product, contiene los atributos Id, CategoryId, Name y Price
    class Product
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }
}