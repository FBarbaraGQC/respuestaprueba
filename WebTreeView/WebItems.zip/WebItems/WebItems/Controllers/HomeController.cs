﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebItems.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            string filePath = Server.MapPath("~/App_Data/Items.json");
            string json = System.IO.File.ReadAllText(filePath);

            List<Item> itemList = JsonConvert.DeserializeObject<List<Item>>(json);

            string html = BuildTree(itemList);

            ViewBag.Html = html;

            return View();
        }

        private string BuildTree(List<Item> itemList)
        {
            string html = "<ul>";

            int level = 0;

            //creamos el ciclo for sobre la lista de items
            for (int i = 0; i < itemList.Count; i++)
            {
                //Comprobamos si el nivel del item actual es mayor que el nivel anterior
                if (itemList[i].Name.Split('.').Length > level)
                {
                    //Si es mayor, incrementamos el nivel en 1
                    level++;
                }
                else
                {
                    //Si es menor o igual, restamos el nivel en 1
                    level--;
                    html += "</li>";
                }

                //Agregamos los espacios al HTML con un for loop, dependiendo del nivel del item en la lista
                for (int j = 0; j < level; j++)
                {
                    html += "&nbsp;&nbsp;";
                }

                //Agregamos el nombre del item como un <li> dentro de la lista <ul>
                html += "<li>" + itemList[i].Name;

                //Si el item tiene hijos, llamamos a la misma función de forma recursiva para construir el orden indicado
                if (itemList[i].Children.Count > 0)
                {
                    html += BuildTree(itemList[i].Children);
                }
            }

            html += "</li></ul>";
            return html;
        }
    }

}
    public class Item
    {
        public string Name { get; set; }
        public List<Item> Children { get; set; }
    }

