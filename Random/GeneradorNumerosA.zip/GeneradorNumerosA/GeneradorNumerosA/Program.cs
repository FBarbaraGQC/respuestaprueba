﻿
using System;
using System.IO;

namespace GeneradorNumerosAleatorios
{
    class Program
    {
        static void Main(string[] args)
        {
            // Se define la cantidad de números a generar 
            int cantidadNumeros = 10000000;
            int rangoMaximo = Int32.MaxValue;

            // Se genera una semilla aleatoria para garantizar la igual probabilidad de los números
            Random rng = new Random();

            // Se crea un archivo de texto para almacenar los números generados
            StreamWriter archivo = new StreamWriter("numeros.txt");

            // Se recorre la cantidad de números definida y se generan aleatoriamente
            for (int i = 0; i < cantidadNumeros; i++)
            {
                int numero = rng.Next(rangoMaximo); // Se genera un número aleatorio dentro del rango máximo

                // Se escribe el número en el archivo de texto
                archivo.WriteLine(numero);
            }

            // Se cierra el archivo
            archivo.Close();

            // Se muestra un mensaje indicando la finalización del proceso
            Console.WriteLine("Se generaron 10.000.000 de números aleatorios en el archivo numeros.txt");
        }
    }
}
 