﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace AppCustomer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var customers = GetCustomers();
            var result = new DataBaseOperations().InsertBulkRecords<Customer>(customers);
            if (result)
            {
                Console.WriteLine("Success");
            }
            Console.ReadKey();
        }
        static List<Customer> GetCustomers()
        {
            string jsonFile = "C:\\Users\\andre\\Downloads\\PruebasCandidatos (1)\\PruebasCandidatos\\Customers\\Customers.csv";
            List<Customer> customers = new List<Customer>();
            var lines = File.ReadAllLines(jsonFile);
            int i = 0;
            while (i < lines.Length)
            {
                // Convertimos la línea en un objeto Customer
                var line = lines[i].Split(';');
                var customer = new Customer
                {
                    Id = line[0],
                    Name = line[1],
                    Address = line[2],
                    City = line[3],
                    Country = line[4],
                    PostalCode = line[5],
                    Phone = line[6]
                };

                // Agregamos el objeto Customer a la lista
                customers.Add(customer);

                // Incrementamos el contador para pasar a la siguiente línea
                i++;
            }
            return customers;
        }
    }
    public class DataBaseOperations
    {
        public bool InsertBulkRecords<T>(List<T> records)
        {
            bool inserted = false;
            DataTable dt = GetTable(records);
            using (SqlConnection cn=GetConnection())
            {
                SqlBulkCopy bcp = new SqlBulkCopy(cn);
                bcp.DestinationTableName = "Customers";
                cn.Open();
                bcp.WriteToServer(dt);
                inserted = true;
            }

            return inserted;
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection("Data Source=ANDRESU24-W11\\SQLEXPRESS01;Initial Catalog=datacustomer;Integrated Security=True;Encrypt=False");
        }

        public DataTable GetTable<T>(List<T> records)
        {
            DataTable dt = new DataTable();
            var type = typeof(T);

            for (int i = 0; i < records.Count(); i++)
            {
                dt.Rows.Add(dt.NewRow());
            }

            foreach (var prop in type.GetProperties())
            {
                DataColumn cl = new DataColumn(prop.Name);
                cl.DataType = prop.PropertyType;
                dt.Columns.Add(cl);

                int rowIndex = 0;

                foreach (var item in records)
                {
                    DataRow dr = dt.Rows[rowIndex++];
                    dr[prop.Name] = prop.GetValue(item);
                }
            }

            return dt;
        }
    }

    public class Customer
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
    }
}



